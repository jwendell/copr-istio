// +build appengine

package internal

func BytesToString(b []byte) string {
	return string(b)
}
