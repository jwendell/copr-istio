# Galley

Galley provides configuration management services for Istio.

It is currently under early development.
